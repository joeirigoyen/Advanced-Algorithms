#ifndef Arbol_H_INCLUDED
#define Arbol_H_INCLUDED
#include "Node.h"
#include <string>
#include <iostream>

using std::cout;
using std::string;

// Diego Armando Ulibarri Hernández
// María Fernanda Ramírez Barragán
// Raul Youthan Irigoyen Osorio

template <typename T>
class Tree
{
	private:
		int list_size{};
		Node<T> *root{};

	public:   
		// Tree constructor
		Tree()
		{
			list_size = 0;
			root = new Node<T>();
			root -> left = nullptr;
			root -> right = nullptr;
		} 

		// Add the element to the tree on the corresponding position
		void push(int element) // Complexity O(N)
		{
			Node<T> *i = root;
			Node<T> *new_node = new Node<T>(element);
			if (list_size == 0){
				root = new_node;
				list_size ++;
				return;
			}
			while(true){
			// Check if new node = i
				if((new_node -> data) == (i -> data)){
					break;
				}
				// Check if the new node < i
				if((new_node -> data) < (i -> data)){
				// Check if the left value of i its equal to nullptr
					if(i -> left == nullptr){
						i -> left = new_node;
						// i -> left -> parent = i;
						new_node -> parent = i;
						list_size ++;
						break;
					}
					i = i -> left;
				}
				// Check if the new node > i 
				else if((new_node -> data) > (i -> data))
				{
				// Check if the right value of i its equal nullptr
					if(i -> right == nullptr){
						i -> right = new_node;
						new_node -> parent = i;
						list_size ++;
						break;
					}
					i = i -> right;
				}
			}     
		}
      
		// Return the highest value on the tree
		int top()// Complexity O(N)
		{
			Node<T> *i = root;
			while (true){
				if (list_size == 0){
					cout << "No hay valor, el arbol esta vacio." << "\n";
					return 0;
				}
				if (i -> right == nullptr){
					return i -> data;
				}
				i = i->right;
			}
		}

		// Delete the higuest value of the tree
		void pop() //Complexity O(N)
		{
			Node<T> *i = root;
			if (list_size == 0)
			{
				cout << "El arbol esta vacio." << "\n";
				return;
			}
			else 
			{
				if(i -> right == nullptr && i -> left == nullptr)
				{
					cout << i -> data << " Este es la raiz." << "\n";
					T removed{i -> data};
					delete i;
					list_size --;
					return;
				}

				if(i -> right == nullptr)
				{
					root = i -> left;
					// Prints
					cout << i -> data << " Este es la raiz." << "\n";
					T removed{i -> data};
					delete i;
					list_size --;
					return;
				}

				else
				{
					while(true)
					{
						if(i -> right -> right == nullptr){
							// prints
							cout << i -> right -> data;
							if(i -> right -> left != nullptr){
								cout << " Este tiene un hijo a la izquierda = "  << i -> right -> left -> data << "\n";
							}else {
								cout << " Este valor es una hoja." << "\n";
							}

							Node<T> *del = i -> right;
							i -> right = i -> right -> left;
							T removed{del -> data};
							delete del;
							list_size--;
							break;
						}
						i = i -> right;
					}
				}
			}
		}

		void displayTree()
		{
			Node<T> *i = root;
			string lines = "";
			int lines_added = 1;
			int parent_changed;
			while(!empty()){
				if(i -> right == nullptr){
					// Print the higues value.
					cout << lines << "->" <<i -> data << "\n";
					Node<T> *del = i;			// Pointer to the node we are going to delete.
					if(i -> left == nullptr){
						if(parent_changed == i -> data){
							lines.erase(lines.end() - (10 * lines_added), lines.end());
							lines_added = 1;
						} else {
							lines.erase(lines.end() - 10, lines.end());
						}
						if(i -> parent != nullptr){
							i -> parent -> right = nullptr;
						}
					} else {
						if(i -> parent == nullptr){
							lines += "          ";
							i -> left -> parent = nullptr;
						} else {
							lines_added += 1;
							i -> parent -> right = i -> left;
							i -> left -> parent = i -> parent;
							parent_changed = i -> left -> data;		// number which the parent has changed Ex. 8
						}
					}
					if (i -> parent != nullptr){
						i = i -> parent;
					} else if(i -> left != nullptr){
						i = i -> left;
					}
					T removed{del -> data};
					delete del;
					list_size --;
				} 
				if(i -> right != nullptr){
					lines += "          ";
					i = i -> right;
				}
			}
			return;
		}

		// Return the size of the tree
		int size()// Complejidad de O(1)
		{
			return list_size;
		}
		
		// Return Boolean
		bool empty()// Complexity O(1)
		{
			return list_size == 0;
		}
		// Delete all the elements of the tree.
		void clear()// Complexity O(N)
		{
			while(list_size > 0)
			{
				pop();
			}
		}
		
		// Destructor
		~Tree()// Complexity O(N)
		{
			clear();
			delete root;
		}  
};

#endif
