#ifndef NODE_H_INCLUDED
#define NODE_H_INCLUDED
template <typename T>
class Node
{
public:
    T data{};
	// Node can have a parent.
	Node<T> *parent{};
	// Node can go left or right 
    Node<T> *right{};
    Node<T> *left{};
	

    // Constructs a new node containing a default value
    Node()
    {
        parent = nullptr;
		right = nullptr;
        left = nullptr;
    }

    // Constructs a new node containing `data`
    Node(T data)
    {
        this->data = data;
		parent = nullptr;
        right = nullptr;
        left = nullptr;
    }
};

#endif // NODE_H_INCLUDED