#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include "Tree.h"
#include "Node.h"

using namespace std;

// Diego Armando Ulibarri Hernández
// María Fernanda Ramírez Barragán
// Raul Youthan Irigoyen Osorio
int main() {
	// Initiate an instance of the tree
	Tree<int> *tree = new Tree<int>;
	string line;
	ifstream file("test.txt");
	while (!file.eof()){
		cout << "Se creara un arbol con lo siguientes números";
		getline(file, line);
		stringstream ss(line);
		while (ss.good()) {
			string num;
			getline(ss, num, ',');
			if (num != "\0") {
				int n = stoi(num);
				cout << " " << n;
				tree -> push(n);
			};
		}
		cout << "\n\n" ;
		tree -> displayTree();
		tree -> clear();
		cout << "\n\n\n" << endl;
	}
}
