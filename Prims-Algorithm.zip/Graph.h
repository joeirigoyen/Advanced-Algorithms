#ifndef GRAPH_H_INCLUDED
#define GRAPH_H_INCLUDED

#include <iostream>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <cmath>
#include <string> 
#include <vector>
#include <deque>

using namespace std;

template <typename T>
class Graph
{
private:
    vector<T> nodes{};
    vector<vector<T>> adjacency{};
	vector<vector<T>> weights{};
	vector<vector<T>> minimun_spanning_tree{};

    int get_node_index(T node)
    {
        int i = 0;
        for(auto n : nodes)
        {
            if(node == n)
            {
                return i;
            }
            ++i;
        }
        return -1;
    }

	void add_edge_spaningtree(T src, T dst)
	{
		int i = get_node_index(src);
		int j = get_node_index(dst);
		minimun_spanning_tree[i].push_back(dst);
		minimun_spanning_tree[j].push_back(src);
	}

	void spanningtree_adjacency_matrix()
	{
		ofstream MyFile("outputPrim.txt");
		int actual = 0;
		cout << "\t";
		MyFile << "\t";
		for(int i = 0; i < nodes.size(); ++i)
		{
			cout << nodes[i] << "\t";
			MyFile << nodes[i] << "\t";
		}
		MyFile << "\n";
		cout << "\n";
		for(int i = 0; i < nodes.size(); ++i)
		{
			cout << nodes[i] << "\t";
			MyFile << nodes[i] << "\t";
			for(int j = 0; j < nodes.size(); ++j)
			{
				if(minimun_spanning_tree[i].size() > 0 && find(minimun_spanning_tree[i].begin(), minimun_spanning_tree[i].end(), nodes[j]) != minimun_spanning_tree[i].end()){
					cout << "1" << "\t";
					MyFile << "1" << "\t";
					actual ++;
				} else {
					cout << "0" << "\t";
					MyFile << "0" << "\t";
				}
			}
			actual = 0;
			cout << "\n";
			MyFile << "\n";
		}
		MyFile.close();
	}

public:

	bool add_node(T node)
	{
		if(get_node_index(node) == -1)
		{
			nodes.push_back(node);
			adjacency.push_back(vector<T>());
			weights.push_back(vector<T>());
			minimun_spanning_tree.push_back(vector<T>());
			return true;
		}
		return false;
	}

	void add_edge(T src, T dst, T weight)
	{
		int i = get_node_index(src);
		int j = get_node_index(dst);
		if(i == -1)
		{
			add_node(src);
			i = get_node_index(src);
		}
		if(j == -1)
		{
			add_node(dst);
			j = get_node_index(dst);
		}
		// Potencialmente revisar que arco no exista
		adjacency[i].push_back(dst);
		adjacency[j].push_back(src);

		weights[i].push_back(weight);
		weights[j].push_back(weight);
	}

	void print()
	{
		for(int i = 0; i < nodes.size(); ++i)
		{
			cout << nodes[i] << ": ";
			for(auto j : adjacency[i])
			{
				cout << j << " | ";
			}
			cout << "\n";
		}
	}

	void adjacency_matrix()
	{
		int actual = 0;
		cout << "\t";
		for(int i = 0; i < nodes.size(); ++i)
		{
			cout << nodes[i] << "\t";
		}
		cout << "\n";
		for(int i = 0; i < nodes.size(); ++i)
		{
			cout << nodes[i] << "\t";
			for(int j = 0; j < nodes.size(); ++j)
			{
				if(adjacency[i].size() > 0 and adjacency[i][actual] == nodes[j]){
					cout << "1" << "\t";
					actual ++;
				} else {
					cout << "0" << "\t";
				}
			}
			actual = 0;
			cout << "\n";
		}
	}

	vector<T> get_nodes()
	{
		vector<T> n(nodes.size());
		for(int i = 0; i < nodes.size(); ++i)
		{
			n[i] = nodes[i];
		}
		return n;
	}

	void prims_algorithm(){
 		int i =  get_node_index(nodes[0]);
		if(i == -1) return;
		deque<T> q{};
		vector<bool> visited(nodes.size());
		bool neighboor = false; 
		q.push_back(nodes[0]);
		visited[i] = true;

		int dst = 0;
		int src = 0;
		int save = 0;
		int smallest_weight = 999999999;
		int n;
		cout << "rout: " << nodes[0];

		while(!q.empty()){
			for(auto y : q){
				i = get_node_index(y);
				src = i;
				for(auto j : adjacency[i]){
					i = get_node_index(j);
					if(visited[i] == false && weights[src][dst] < smallest_weight)
					{
						smallest_weight = weights[src][dst];
						//cout << endl << nodes[src] << "->" << nodes[i] << "->" << smallest_weight;
						save = src;
						n = i;
					}
					++ dst;
				}
				if(n == 0){
					q.erase(q.begin());
				}
				if(q.empty()){
					break;
				}
				dst = 0;
			}
			if(q.empty()){
				break;
			}
			//cout << endl << "break" << endl;
			//cout << endl << nodes[save] << "->" << nodes[n];
			add_edge_spaningtree(nodes[save], nodes[n]);
			cout << " " << nodes[n];
			smallest_weight = 999999999;
			visited[n] = true;
			q.push_back(nodes[n]);
			n = 0;
		} 
		cout << "\n\n";
		spanningtree_adjacency_matrix();
	}
}; 

#endif
