#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include "Graph.h"

using namespace std;
// Diego Armando Ulibarri Hernández
// María Fernanda Ramírez Barragán
// Raul Youthan Irigoyen Osorio

int main() {
	string line;
	string graph1 = "";
	string graph2 = "";
	string weight = "";
	int value1 = 0;
	int value2 = 0;
	int value3 = 0;
	int graph_turn = 0;
	ifstream file("prim3.txt");
	Graph<int> g{};

	if(!file){
		cout << "Imposible abrir el archivo prim.txt asegurese que este en la línea correcta.";
		return 1;
	}
	// Read file and create digraph
	while(getline(file, line)){
		for(char& c : line){
			if(c == ','){
				graph_turn += 1;
			}else if(c == ')'){
				//cout << graph1 << " -> " << graph2 << " -> " << weight << endl;
				value1 = stoi(graph1);
				value2 = stoi(graph2);
				value3 = stoi(weight);
				g.add_edge(value1, value2, value3);
				graph_turn = !graph_turn;
				graph1 = "";
				graph2 = "";
				weight = "";
				graph_turn = 0;
			} else if (c != '(' && c != ' '){
				if(graph_turn == 0){ // graph 1 value
					graph1 += c;
				} else if(graph_turn == 1) { // graph 2 value
					graph2 += c;
				} else {	// graph 3 value
					weight += c;
				}
			}
		}
	}
	
	cout << "Graph representatio by adjacency list\n\n";
	g.print();
	cout << "\nGraph Representation by adjacency matrix before prim's algorithm\n\n";
	g.adjacency_matrix();
	cout << "\nGraph Representation after prim's algorithm\n\n";
	g.prims_algorithm();
	cout << "\n";
}