#ifndef DIGRAPH_H_INCLUDED
#define DIGRAPH_H_INCLUDED

#include <iostream>
#include <cmath>
#include <string> 
#include <vector>
#include <deque>

using namespace std;

template <typename T>
class Digraph
{
private:
    vector<T> nodes{};
    vector<vector<T>> adjacency{};
	vector<vector<T>> inlinks{};
	vector<vector<T>> outlinks{};

    int get_node_index(T node)
    {
        int i = 0;
        for(auto n : nodes)
        {
            if(node == n)
            {
                return i;
            }
            ++i;
        }
        return -1;
    }

public:

	bool add_node(T node)
	{
		if(get_node_index(node) == -1)
		{
			nodes.push_back(node);
			adjacency.push_back(vector<T>());
			inlinks.push_back(vector<T>());
			outlinks.push_back(vector<T>());
			return true;
		}
		return false;
	}

	void add_edge(T src, T dst)
	{
		int i = get_node_index(src);
		int j = get_node_index(dst);
		if(i == -1)
		{
			add_node(src);
			i = get_node_index(src);
		}
		if(j == -1)
		{
			add_node(dst);
			j = get_node_index(dst);
		}
		// Potencialmente revisar que arco no exista
		adjacency[i].push_back(dst);
		inlinks[j].push_back(src);
		outlinks[i].push_back(dst);
	}

	void print()
	{
		for(int i = 0; i < nodes.size(); ++i)
		{
			cout << nodes[i] << ": ";
			for(auto j : adjacency[i])
			{
				cout << j << " | ";
			}
			cout << "\n";
		}
	}

	void adjacency_matrix()
	{
		int actual = 0;
		cout << "\t";
		for(int i = 0; i < nodes.size(); ++i)
		{
			cout << nodes[i] << "\t";
		}
		cout << "\n";
		for(int i = 0; i < nodes.size(); ++i)
		{
			cout << nodes[i] << "\t";
			for(int j = 0; j < nodes.size(); ++j)
			{
				if(adjacency[i].size() > 0 and adjacency[i][actual] == nodes[j]){
					cout << "1" << "\t";
					actual ++;
				} else {
					cout << "0" << "\t";
				}
			}
			actual = 0;
			cout << "\n";
		}
	}

	vector<T> get_nodes()
	{
		vector<T> n(nodes.size());
		for(int i = 0; i < nodes.size(); ++i)
		{
			n[i] = nodes[i];
		}
		return n;
	}
  

	void dfs(T node)
	{
		int i =  get_node_index(node);
		if(i == -1) return;
		deque<T> q{};
		vector<bool> visited(nodes.size());
		bool neighboor = false; 
		q.push_back(node);
		visited[i] = true;
		cout << node << " ";
			
		while(!q.empty())
		{ 
			neighboor = false;
			for(auto j : adjacency[i])
			{
				neighboor = true;
				i = get_node_index(j);
				if(visited[i] == false)
				{
					q.push_back(j);
					visited[i] = true;
					cout << j << " ";
					break;
				}
				else {
					neighboor = false;
				}
			} 
			if(!neighboor){
				q.pop_back();
				if(q.size() == 0){
					break;
				}
				i = get_node_index(q.back());
			}
		}
	}


	vector<vector<string>> pagerank()
	{
		vector<vector<string>> pr(nodes.size());
		int round = 0;
		double fraction_value = 0.0;
		string temporal_value;
		vector<vector<double>> round_values{};
		
		while (round < 5){
			for(int i = 0; i < nodes.size(); ++i)
			{
				if(round == 0){
					pr[i].push_back(to_string(nodes[i]));
					pr[i].push_back(to_string(inlinks[i].size()));
					pr[i].push_back(to_string(outlinks[i].size()));	
					temporal_value = "r(P" + to_string(nodes[i]) + ")";
					pr[i].push_back(temporal_value);
					fraction_value = 1.0/nodes.size();				
					round_values.push_back({fraction_value});
					temporal_value = to_string(fraction_value);
					pr[i].push_back(temporal_value);
					fraction_value = 0.0;			
				} else {
					for(auto j : inlinks[i])
					{
						// tiene el index de uno de los valores de inlinks
						int r = get_node_index(j);
						fraction_value += round_values[r][round - 1] / outlinks[r].size();
					}
					round_values[i].push_back(fraction_value);
					temporal_value = to_string(fraction_value); 
					pr[i].push_back(temporal_value);
					fraction_value = 0.0;
				}
			}
			round ++;
		}
		return pr;
	}

  
	void topological(){
		int i =  get_node_index(nodes[0]);
		if(i == -1) return;
		deque<T> q{};
		vector<T> topologico{};
		vector<bool> visited(nodes.size());
		bool neighboor = false; 
		q.push_back(nodes[0]);
		visited[i] = true;
			
		while(!q.empty())
		{
			neighboor = false;
			for(auto j : adjacency[i])
			{
				neighboor = true;
				i = get_node_index(j);
				if(visited[i] == false)
				{ 
					q.push_back(j);       
					visited[i] = true;
					break;
				}
				else {
					neighboor = false;
				}
			}
			if(!neighboor){
				topologico.push_back(q.back());
				q.pop_back();
				if(q.size() == 0){
					break;
				}
				i = get_node_index(q.back());
			}
		}

		cout << "Orden topologico: ";
		for(int k = 0; k < topologico.size(); k ++){
			cout << topologico[k] << " ";
		}
		cout << "\n\n";
	}
}; 

#endif
