#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include "Digraph.h"

using namespace std;
// Diego Armando Ulibarri Hernández
// María Fernanda Ramírez Barragán
// Raul Youthan Irigoyen Osorio

int main() {
	string line;
	int graph1 = 0;
	int graph2 = 0;
	bool graph_turn = true;
	ifstream file("PageRank.txt");
	ofstream page_rank_file;
	Digraph<int> dg{};

	if(!file){
		cout << "Imposible abrir el archivo PageRank.txt asegurese que este en la línea correcta.";
		return 1;
	}
	// Read file and create digraph
	while(getline(file, line)){
		for(char& c : line){
			if(c == ','){
				graph_turn = !graph_turn;
			}else if(c == ')'){
				dg.add_edge(graph1, graph2);
				graph_turn = !graph_turn;
				graph1 = 0;
				graph2 = 0;
			} else if (c != '('){
				if(graph_turn){
					graph1 += c - '0';
				} else {
					graph2 += c - '0';
				}
			}
		}
	}
	cout << "\nGraph Representation by adjacency list. \n\n";
	// Imprimir grafo
	dg.print();
	cout << "\nGraph Representation by adjacency matrix.\n\n";
	dg.adjacency_matrix();
	cout << "\n";

	// Creating csv file and printing PageRank
	page_rank_file.open("PageRank.csv");
	page_rank_file << "Node, Inlinks, Outlinks, PageRank, Round0, Round1, Round2, Round3, Round4" << endl;
	cout << "Node Inlinks Outlinks PageRank\t\tRound0\t\t\tRound1\t\t\tRound2\t\t\tRound3\t\t\tRound4\n";
	vector<vector<string>> pr = dg.pagerank();
	for(int i = 0; i < pr.size(); ++i){
		for(auto j : pr[i]){
			page_rank_file << j << ",";
			cout << j << "\t\t";
		}
		page_rank_file << endl;
		cout << endl;
	}
}